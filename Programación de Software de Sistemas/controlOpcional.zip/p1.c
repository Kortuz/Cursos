#include <string.h>
#include <stdio.h>

void desplazarDer(char *s, int n){
    int l = strlen(s);
    char* p;
    p = s;
    while(l-1){
        p++;
        l--;
    }
    char* q;
    q = p;
    int m = n;
    while(m){
        q--;
        m--;
    }

    l = strlen(s);
    int i = n;
    while(l-n-1 >= 0){
        *p = *q;
        q--;
        p--;
        n--;
    }
    while(i){
        *q =' ';
    }
    printf("%s\n", s);
}


