
#include <stdlib.h>
#include <stdio.h>

typedef struct nodo {
    int x;
    struct nodo *prox;
} Nodo;

int extraerUltimo(Nodo **plista){
    Nodo* n;
    Nodo* m;
    n = *plista;
    m = *plista;
    if(m->prox != NULL){
        n = n->prox;
    } else{
        *plista = NULL;
    }
    while(n->prox != NULL){
        n = n->prox;
        m = m->prox;
    }
    m->prox = NULL;
    int value = n->x;
    free(n);
    return  value;
}