#include <pthread.h>

enum { LEFT= 0, RIGHT= 1 };
int busy[2]= { 0, 0 }; // Ambas mitades libres

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

int halfLock() {

    while(busy[LEFT] && busy[RIGHT]){
        pthread_mutex_lock(&mutex);
        pthread_cond_wait(&cond, &mutex);
        pthread_mutex_unlock(&mutex);
    }
    if(busy[LEFT] && !(busy[RIGHT])){
        busy[LEFT] = 1;
        return  LEFT;
    }
    if(busy[RIGHT] && !(busy[LEFT])){
        busy[RIGHT] = 1;
        return RIGHT;
    }

    busy[LEFT] = 1; // se decide que si estan los dos libres se use primero el LEFT
    return LEFT;
}
void halfUnlock(int side) {
    busy[side]= 0;
    if(!(busy[RIGHT] || busy[LEFT])){
        pthread_cond_broadcast(&cond);
    }
    pthread_cond_broadcast(&cond);

}
void fullLock() {
    pthread_mutex_lock(&mutex);
    while ( busy[LEFT] || busy[RIGHT]){
        pthread_cond_wait(&cond, &mutex);
    }
    busy[LEFT]= busy[RIGHT]= 1;
}
void fullUnlock() {
    busy[LEFT]= busy[RIGHT]= 0;
    pthread_mutex_unlock(&mutex);
}