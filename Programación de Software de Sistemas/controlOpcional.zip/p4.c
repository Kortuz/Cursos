#include <pthread.h>

int maxSequencial(int* a, int n, int i, int j){
    int max = a[i];
    while(j-i){
        i++;
        if(a[i] > max){
            max = a[i];
        }
    }
    return max;
}

typedef  struct{
    int* a;
    int n;
    int i;
    int j;
    int max;    // para guardar la solución
}   Args;

void *thread_function(void *params){
    Args *p = (Args *) params;
    int* a = p->a;
    int n = p->n;
    int i = p->i;
    int j = p->j;
    p->max = maxSequencial(a, n, i, j);

}


int maxArreglo(int a[], int n, int p){
    pthread_t  t[8] ;
    Args  args [sizeof(Args)] ;
    int step = n/p;
    int s = 0;
    for(int  k = 0;  k<p;  k++){
        args[k].a = a;
        args[k].n = n;
        args[k].i = s;
        args[k].j = s + step - 1;
        s = s + step;

        //  lanzar  thread
        pthread_create(&t[k] , NULL,  thread_function , &args[k]) ;
    }
    int max = 0;
    //  espera los threads
    for(int k = 0; k<p; k++) {
        pthread_join(t[k], NULL);
        if (args[k].max > max) {
            max = args[k].max;  //  guardo el maximo de los max
        }
    }
    return max;

}