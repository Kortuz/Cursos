#define _XOPEN_SOURCE 500
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>

int leer(int fd, void *buf, int n) {
    if (n==0)
        return 0;
    do {
        int rc= read(fd, buf, n);
        if (rc<=0)
            return 1;  // fracaso: error o fin del archivo/pipe/socket
        n-= rc;      // descontamos los bytes leídos
        buf= (char*)buf + rc; // avanzamos el buffer
    }
    while (n>0); // mientras no leamos todo lo que esperamos
    return 0;      // exito
}

int maxSequencial(int* a, int n, int i, int j){
    int max = a[i];
    while(j-i){
        i++;
        if(a[i] > max){
            max = a[i];
        }
    }
    return max;
}

int maxArreglo(int a[], int n, int p){
    int max = MININT; // iniciamos el maximo como el numero mas negativo
    int infds[p];
    int pids[p];
    int results[p];
    int ini = 0;
    int step = n/p;
    //creando hijos
    for(int i = 0; i < p; i++;){
        pid_t child = fork();
        int fds[2];
        pipe(fds);
        if(child == 0){   // hijo
            close(fds[0]);   // hijo solo escribe el resultado
            int result = maxSequencial(a, ini, ini + step, step);
            write(fds[1], &result, sizeof(int));
            close(fds[1]);   //cierro el pipe
            exit(0); //matamos al hijo
        }
        else{   //padre
            close(fds[1]);   // padre solo lee los resultados
            maxSequencial(results, n, 0, n);
            infds[i] = fds[0];
        }
        ini+=step;
    }
    for (int i = 0; i < p; ++i) { // esperamos a los hijos
        waitpid(pids[i], NULL, 0); //esperamos y enterramos los hijos
        int maxSec;
        leer(infds[i], &maxSec, 1*sizeof(int)); //vemos el maximo de los hijos
        if(max < maxSec){
            max = maxSec;
        }
    }
    return  max;
}

