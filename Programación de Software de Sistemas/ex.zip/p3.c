//
// Created by Zeba_ on 8/5/2020.
//

#include <pthread.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

int readers= 0, disp= 0, serial= 0;

void enterRead() {
    pthread_mutex_lock(&mutex);
    int myNum= serial++;
    while (myNum!=disp){
        pthread_cond_wait(&cond, &mutex);   //esperamos a que terminen de escribir
    }
    readers++; disp++;
    pthread_mutex_unlock(&mutex);
}
void exitRead() {
    pthread_mutex_lock(&mutex);
    readers--;
    if (readers==0){
        pthread_cond_broadcast(&cond);  //despertamos al escritor si es que no quedan mas lectores
    }
    pthread_mutex_unlock(&mutex);
}

void enterWrite() {
    pthread_mutex_lock(&mutex);
    int myNum = serial++;
    while (readers > 0 || myNum != disp){
        pthread_cond_wait(&cond, &mutex);   //esperamos si hay gente leyendo o si hay alguien escribiendo
    }
    pthread_mutex_unlock(&mutex);
}
void exitWrite() {
    pthread_mutex_lock(&mutex);
    disp++; //aumentamos el disp y queda a la par con serial
    pthread_cond_broadcast(&cond);  //despertamos treads esperando a este escritor
    pthread_mutex_unlock(&mutex);
}
