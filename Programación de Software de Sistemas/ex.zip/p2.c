//
// Created by Zeba_ on 8/5/2020.
//
#include <stdio.h>

typedef struct nodo {
    char *s;
    struct nodo *der;
    struct nodo *izq;
} Nodo;

int k_hojas(Nodo *t, Nodo **pa, int k){
    int result = 0;
    if(t == NULL){  // retorna 0 si el arbol es nulo
        return 0;
    }
    if(t->izq == NULL && t->der == NULL && k != 0){   //aumentamos en uno el resultado si es una hoja
        result ++;
        *pa = t;    //insertamos en pa
        pa++;   //movemos el pa
        k--;
    }
    else if(k != 0){
        result += k_hojas(t->der, pa, k);    //recursión hacia la derecha del árbol y aumentamos
        result += k_hojas(t->izq, pa, k);    //recursión hacia la izquierda del árbol y aumentamos
    }
    if(k == 0){
        return result;
    }
    return result; //return the result
}