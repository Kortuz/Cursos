//
// Created by Zeba_ on 8/5/2020.
//
#include <string.h>

void elimChar(char *str, char c){
    char* p;
    char* q;
    p = str;
    int l = strlen(str);    //largo del string
    while(c == *p){ //revisamos si parte con caracteres "c" y movemos el str[0] hacia la derecha
        p++;
        str = p;
        l--;
    }
    q = p;
    q++;
    while(l){   //ahora con el largo que queda quitamos los "c" caracteres
        if(c == *q){    //vemos si el siguiente caracter es "c"
            q++;    //dejamos el puntero 2 mas lejos
            p = q;  //saltamos el caracter "c" de la posicion anterior al q
        }
        p++;
        q++;
        l--;
    }
}
